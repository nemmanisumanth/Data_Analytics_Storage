# Organization_Exploratory_Data_Analysis

Questions:
1.	What factors contribute most to associates leaving the organization?
2.	Is there any multi-collinearity associated with-in variables provided?
3.	Predict Turnover for following groups:
       a.	Overall
       b.	For People Leaders and Individual Contributor
       c.	For new associates (<2 years) and tenured associates
4.	Present your findings by using a Power BI/Tableau dashboard.
